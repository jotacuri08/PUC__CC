import mypackage.MyIO;
public class u00g_10 {
    public static void main (String[] args){
        int num = 0;
        while(num < 11){
            MyIO.println(num);
            num++;
        }
    }
}
