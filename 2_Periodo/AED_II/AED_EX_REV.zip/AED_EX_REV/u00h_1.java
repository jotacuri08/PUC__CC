package AED_EX_REV;

public class u00h_1 {
    public static void mostra3(){
        for(int i = 0; i < 3; i++){
            System.out.println(i + 1);
        }
    }
}

